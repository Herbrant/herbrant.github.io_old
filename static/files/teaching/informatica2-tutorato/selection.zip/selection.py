from random import randint
from math import ceil

def insertion_sort(arr):
	for i in range(0,len(arr)):
		key = arr[i]
		j = i-1

		while j >= 0 and key < arr[j]:
			arr[j+1] = arr[j]
			j -= 1
		
		arr[j+1] = key
	
	return arr

def getMediana(arr):
	if len(arr) % 2 == 0:
		return arr[len(arr)//2 -1]
	else:
		return arr[len(arr)//2]

def selection(arr, num, H):
	if num > len(arr) or num < 1:
		return None
	
	if len(arr) < 40:
		return insertion_sort(arr)[num-1]
	
	n = ceil(len(arr)/H)
	M = []

	for i in range(n):
		m = []
		for j in range(H):
			if (H*i+j) < len(arr):
				m.append(arr[H*i+j])
		
		m = insertion_sort(m)
		M.append(getMediana(m))
	
	if(len(M) % 2 == 0):
		med = selection(M, len(M)//2+1, H)
	else:
		med = selection(M, len(M)//2, H)
	
	A1, A2, A3 = [], [], []

	for i in range(len(arr)):
		if arr[i] < med:
			A1.append(arr[i])
		elif arr[i] == med:
			A2.append(arr[i])
		else:
			A3.append(arr[i])
	
	if len(A1) >= num:
		return selection(A1, num, H)
	elif (len(A2)+len(A2)) >= num:
		return m
	else:
		return selection(A3, num - (len(A1)+len(A2)), H)

		



A = [randint(1,100) for i in range(100)]
print(insertion_sort(A))
print(selection(A, 4, 5))