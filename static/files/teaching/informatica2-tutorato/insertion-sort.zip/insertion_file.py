def insertion_sort(arr):
	for i in range(1, len(arr)):
		key = arr[i]

		j = i - 1

		while j > -1 and key < arr[j]:
			arr[j+1] = arr[j]
			j -= 1
		
		arr[j+1] = key

	return arr

def array_to_file(arr, output_file):
	for el in arr[:-1]:
		output_file.write("{} ".format(el))
	
	output_file.write("{}\n".format(arr[len(arr) - 1]))


def solve(input_file, output_file):
	input = input_file.readlines()

	for line in input:
		arr = [int(x) for x in line.split()]
		arr = insertion_sort(arr)
		array_to_file(arr, output_file)


i = open("input.txt", "r")
o = open("output.txt", "w")
solve(i, o)

i.close()
o.close()