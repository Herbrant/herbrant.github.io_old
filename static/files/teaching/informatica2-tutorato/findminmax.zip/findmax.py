def find_max(arr):
	if len(arr) == 0:
		return -1
	
	max_index = 0

	for i in range(1, len(arr)):
		if arr[max_index] < arr[i]:
			max_index = i
	
	return arr[max_index]


A = [10, 20, 99, 100, 77, 44, 2]
print(find_max(A))