def mergeSort(arr):
	if len(arr) == 1:
		return arr
	
	mid_point = len(arr)//2

	left_partition = mergeSort(arr[:mid_point])
	right_partition = mergeSort(arr[mid_point:])

	return merge(left_partition, right_partition)

def merge(left_partition, right_partition):
	arr = []

	i = j = 0

	while i < len(left_partition) and j < len(right_partition):
		if left_partition[i] < right_partition[j]:
			arr.append(left_partition[i])
			i += 1
		else:
			arr.append(right_partition[j])
			j += 1
	
	arr.extend(left_partition[i:])
	arr.extend(right_partition[j:])
	return arr


arr = [1, 20, 0, 90, 2]
arr = mergeSort(arr)

print(arr)