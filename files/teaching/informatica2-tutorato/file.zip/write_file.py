f = open("output.txt", "w")

out = "Output per test"
f.write(out)

f.close()