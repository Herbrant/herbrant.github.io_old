f = open("lotr.txt", "r")

txt = f.read()
print(txt)

f.close()