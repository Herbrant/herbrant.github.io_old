def insertion_sort(vett):
	for i in range(1, len(vett)):
		key = vett[i]
		j = i-1

		while j >= 0 and key[1] < vett[j][1]:
			vett[j+1] = vett[j]
			j -= 1
		vett[j+1] = key
	
	return vett

A = [(10,11), (99,80), (0,2), (11,20), (0,21), (45,12), (0,0)]
B = insertion_sort(A)
print(B)