def MatrixChainOrder(p, i, j):
	if i == j:
		return 0
	
	max_value = -1

	for k in range(i, j):
		count = MatrixChainOrder(p, i, k) + MatrixChainOrder(p, k+1, j) + p[i-1]*p[k]*p[j]

		if count > max_value:
			max_value = count
	
	return max_value

arr = [1,2,3,4]
n = len(arr)
print(MatrixChainOrder(arr, 1, n-1))