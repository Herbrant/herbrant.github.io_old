def find_min(arr):
	if len(arr) == 0:
		return -1
	
	min_index = 0

	for i in range(1, len(arr)):
		if arr[min_index] > arr[i]:
			min_index = i
	
	return arr[min_index]


A = [10, 20, 99, 100, 77, 44, 2]
print(find_min(A))