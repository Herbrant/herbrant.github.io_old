from sys import maxsize

def MatrixChainOrder(p, i, j):
	if i == j:
		return 0
	
	min = maxsize
	for k in range(i,j):
		count = MatrixChainOrder(p, i, k) + MatrixChainOrder(p, k+1, j) + p[i-1]*p[k]*p[j]

		if count < min:
			min = count
	
	return min

arr = [1,2,3,4]
n = len(arr)
print(MatrixChainOrder(arr, 1, n-1))