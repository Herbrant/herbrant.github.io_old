def merge_sort(vett):
	if len(vett) == 1:
		return vett
	
	mid_point = len(vett)//2

	left_partition = merge_sort(vett[:mid_point])
	right_partition = merge_sort(vett[mid_point:])

	return merge(left_partition, right_partition)

def merge(left_partition, right_partition):
	arr = []

	i = j = 0

	while i < len(left_partition) and j < len(right_partition):
		if left_partition[i][1] < right_partition[j][1]:
			arr.append(left_partition[i])
			i += 1
		else:
			arr.append(right_partition[j])
			j += 1
	
	arr.extend(left_partition[i:])
	arr.extend(right_partition[j:])
	return arr


A = [(0,1),(0,10),(1,20),(4,0), (9,2),(20,3),(4,100),(2,1),(1,0)]
B = merge_sort(A)
print(B)