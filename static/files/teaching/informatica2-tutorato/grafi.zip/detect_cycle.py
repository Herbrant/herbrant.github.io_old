def isCyclicUtil(node, graph, visited, recStack):
	visited.add(node)
	recStack.add(node)

	for neighbour in graph[node]:
		if neighbour not in visited:
			if isCyclicUtil(neighbour, graph, visited, recStack) == True:
				return True
		elif neighbour in recStack:
			return True

def isCyclic(graph):
	visited = set()
	recStack = set()

	for node in graph:
		if node not in visited:
			if isCyclicUtil(node, graph, visited, recStack) == True:
				return True

	return False

graph = {
    'A' : ['B','C'],
    'B' : ['C'],
    'C' : ['A', 'D'],
    'D' : ['D']
}

print(isCyclic(graph))