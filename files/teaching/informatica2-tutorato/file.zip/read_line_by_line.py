f = open("lotr.txt", "r")

txt = f.readlines()
i = 0

for line in txt:
	print("Line {}: {}".format(i, line))
	i += 1

f.close()