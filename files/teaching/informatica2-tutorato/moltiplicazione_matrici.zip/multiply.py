def multiply(X, Y):
	if len(X[0]) != len(Y):
		return None
	
	result = []

	for i in range(len(X)):
		result.append([])
		for j in range(len(Y[0])):
			result[i].append(0)
			for k in range(len(X[0])):
				result[i][j] = result[i][j]+ X[i][k]*Y[k][j]
	
	return result


A = [[3,4,5],[7,3,6]]
B = [[8,5,6],[1,2,1],[2,2,2]]

print(multiply(A,B))