def merge_sort(vett):
	if len(vett) == 1:
		return vett
	
	mid_point = len(vett)//2

	left_partition = merge_sort(vett[:mid_point])
	right_partition = merge_sort(vett[mid_point:])

	return merge(left_partition, right_partition)

def merge(left_partition, right_partition):
	arr = []

	i = j = 0

	while i < len(left_partition) and j < len(right_partition):
		if left_partition[i][1] < right_partition[j][1]:
			arr.append(left_partition[i])
			i += 1
		else:
			arr.append(right_partition[j])
			j += 1
	
	arr.extend(left_partition[i:])
	arr.extend(right_partition[j:])
	return arr

def array_to_file(arr, output_file):
	for el in arr[:-1]:
		output_file.write("{} ".format(el))
	
	output_file.write("{}\n".format(arr[len(arr) - 1]))

def solve(input_file, output_file):
	input = input_file.readlines()

	for line in input:
		line = line.replace('(', ' ').replace(')', ' ').replace(',', ' ').split()
		arr = []

		for i in range(0, len(line), 2):
			arr.append((int(line[i]), int(line[i+1])))
		
		arr = merge_sort(arr)
		array_to_file(arr, output_file)


i = open("input.txt", "r")
o = open("output.txt", "w")
solve(i, o)

i.close()
o.close()
