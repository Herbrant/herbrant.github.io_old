def merge_sort(arr):
	if len(arr) == 1:
		return arr
	
	mid_point = len(arr)//2

	left_partition = merge_sort(arr[:mid_point])
	right_partition = merge_sort(arr[mid_point:])

	return merge(left_partition, right_partition)

def merge(left, right):
	arr = []
	i = j = 0

	while i < len(left) and j < len(right):
		if left[i] < right[j]:
			arr.append(left[i])
			i += 1
		else:
			arr.append(right[j])
			j += 1
		
	arr.extend(left[i:])
	arr.extend(right[j:])
	return arr

def array_to_file(arr, f):
	for x in arr[:-1]:
		f.write("{} ".format(x))
	
	f.write("{}\n".format(arr[len(arr)-1]))

def solve(input_file, output_file):
	input = input_file.readlines()

	for line in input:
		arr = [int(x) for x in line.split()]
		arr = merge_sort(arr)
		array_to_file(arr, output_file)

i = open("input.txt", "r")
o = open("output.txt", "w")
solve(i, o)

i.close()
o.close()
